# Plan para vender a empresas grandes

## Etapa 1: Oferta piloto

Objetivo: conseguir conversaciones y primeros pilotos pagados.

Necesario:

- Demo funcional.
- Landing.
- One pager.
- Pitch.
- Politica de privacidad y terminos en borrador.
- Contrato de piloto.
- Datos ficticios o anonimizados.

Estado: preparado en este kit.

## Etapa 2: SaaS real

Objetivo: permitir uso real con clientes pequenos.

Falta:

- Login.
- Roles: estudiante, docente, admin.
- Base de datos.
- Panel de configuracion institucional.
- Recuperacion de contrasena.
- Seguridad basica en produccion.
- Dominio y HTTPS.
- Registro de eventos.
- Backups.
- Proceso de soporte.

## Etapa 3: Enterprise

Objetivo: vender a empresas grandes, instituciones o marketplaces.

Falta:

- Empresa formal.
- Cuenta bancaria empresarial.
- Contratos revisados por abogado.
- Politica de privacidad final.
- DPA o acuerdo de procesamiento de datos.
- Seguridad documentada.
- Auditoria de vulnerabilidades.
- Logs de auditoria.
- Aislamiento por cliente.
- Cifrado en transito y reposo.
- Roadmap de cumplimiento: COPPA, FERPA, GDPR/CCPA segun mercado.
- Evidencia de pilotos y casos de exito.

## Etapa 4: AWS o Google Marketplace

Objetivo: vender a traves de marketplace cloud.

Falta:

- Producto production-ready.
- Registro como seller/vendor.
- Datos fiscales y bancarios.
- Integracion de facturacion del marketplace.
- Arquitectura alojada en el cloud correspondiente si se quiere mejor posicionamiento.
- Documentacion de soporte, seguridad y manejo de datos.
- Revision del marketplace.

## Mensaje para empresas grandes

No pedir "compren la app" al inicio. Pedir:

- feedback,
- piloto,
- partnership,
- inclusion en programa de startups,
- validacion tecnica,
- canal de marketplace.

La puerta de entrada mas realista es un piloto pequeno con un area de educacion, inclusion, cloud for startups, impacto social o EdTech partnerships.
