# Terminos de uso - Borrador

Aviso: este documento es un borrador y debe ser revisado legalmente antes de uso publico.

## Uso permitido

NeuroPath se ofrece como herramienta educativa de acompanamiento cognitivo. Puede usarse para pilotos, demostraciones y evaluaciones institucionales autorizadas.

## Uso no permitido

No se permite usar NeuroPath para:

- Diagnosticar condiciones medicas.
- Reemplazar profesionales de salud, psicologia o educacion especial.
- Tomar decisiones disciplinarias automatizadas.
- Cargar datos personales de menores sin autorizacion y acuerdos adecuados.
- Vender, compartir o exponer datos de estudiantes.

## Estado del producto

La version actual es un MVP/piloto. Algunas funciones pueden cambiar, mejorar o retirarse durante el proceso de validacion.

## Cuentas y acceso

Los usuarios son responsables de proteger sus credenciales y de usar la plataforma solo dentro del alcance autorizado.

## Propiedad intelectual

NeuroPath, su marca, codigo, diseno y documentacion pertenecen a NEURONOVA GLOBAL, salvo componentes de terceros con sus propias licencias.

## Disponibilidad

Durante pilotos, la disponibilidad puede ser limitada. Cualquier SLA debe pactarse por escrito.

## Limitacion de responsabilidad

NeuroPath entrega recomendaciones educativas de apoyo. Las decisiones finales deben ser tomadas por personas responsables y profesionales autorizados.

## Contacto

Soporte: castellanosanalisis@gmail.com
