# Politica de privacidad - Borrador

Aviso: este documento es un borrador y debe ser revisado legalmente antes de uso publico.

## Que es NeuroPath

NeuroPath es una herramienta educativa de accesibilidad cognitiva. Su objetivo es apoyar a estudiantes, docentes e instituciones con senales y recomendaciones de acompanamiento.

## Datos que podemos recopilar en un piloto

En pilotos iniciales recomendamos usar datos ficticios o anonimizados. Si se usan datos reales, podrian incluir:

- Nombre o identificador de estudiante.
- Indicadores educativos de foco, energia o carga sensorial.
- Alertas de acompanamiento.
- Informacion de uso de la plataforma.
- Datos de contacto de usuarios institucionales.

## Para que usamos los datos

- Mostrar paneles educativos.
- Generar recomendaciones de acompanamiento.
- Evaluar el funcionamiento del piloto.
- Mejorar el producto.
- Dar soporte al cliente piloto.

## Datos de menores

NeuroPath no debe recopilar datos personales de menores sin autorizacion institucional, consentimiento aplicable y acuerdos de privacidad correspondientes. En Estados Unidos pueden aplicar reglas como COPPA y FERPA.

## Datos sensibles

NeuroPath no debe usarse como sistema medico ni para registrar diagnosticos clinicos sin una revision legal, tecnica y de seguridad adicional.

## Compartir datos

No vendemos datos de estudiantes. Los datos del piloto solo se comparten con personal autorizado del proveedor y del cliente, o con proveedores tecnicos necesarios para operar la plataforma.

## Seguridad

La version piloto debe usar medidas razonables de seguridad, incluyendo acceso restringido, HTTPS en produccion, controles de rol y eliminacion de datos cuando termine el piloto.

## Retencion y eliminacion

Los datos del piloto deben eliminarse o anonimizarse al cierre del piloto, salvo acuerdo escrito diferente.

## Contacto

Para preguntas de privacidad: [privacy@example.com]
