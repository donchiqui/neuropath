# Guion de demo - NeuroPath

Duracion sugerida: 12 a 18 minutos.

## 1. Apertura

Gracias por el espacio. NeuroPath es un MVP de accesibilidad cognitiva para equipos educativos. La idea es detectar senales tempranas de fatiga o sobrecarga y convertirlas en acciones simples para estudiantes, docentes e instituciones.

## 2. Aclaracion responsable

Antes de mostrarlo: NeuroPath no diagnostica condiciones medicas ni reemplaza profesionales. Es una herramienta educativa de acompanamiento. Para pilotos iniciales recomendamos usar datos ficticios o anonimizados.

## 3. Vista estudiante

Mostrar:

- Foco.
- Energia.
- Carga sensorial.
- Recomendacion inmediata.
- Bloque de enfoque.

Mensaje clave:

El estudiante no recibe una etiqueta; recibe una accion clara para continuar.

## 4. Vista docente

Mostrar:

- Alertas priorizadas.
- Recomendaciones simples.

Mensaje clave:

El docente no necesita interpretar datos complejos. Ve que requiere atencion y que puede hacer en ese momento.

## 5. Vista institucion

Mostrar:

- Estudiantes activos.
- Cantidad que necesita apoyo.
- Foco promedio.
- Pausas/regulaciones del dia.

Mensaje clave:

La institucion ve tendencias agregadas para mejorar programas de apoyo, no para exponer estudiantes.

## 6. Oferta piloto

Proponemos un piloto de 14 a 30 dias con datos ficticios o anonimizados. Incluye demo personalizada, sesion con su equipo, recopilacion de feedback y reporte de recomendaciones.

## 7. Preguntas de descubrimiento

- Que estudiantes o programas necesitan mas apoyo hoy?
- Como detectan actualmente fatiga, desconexion o sobrecarga?
- Que herramientas usan los docentes?
- Que datos pueden usar de forma segura para un piloto?
- Quien debe aprobar privacidad y tecnologia?

## 8. Cierre

Si tiene sentido, el siguiente paso es elegir un caso de uso pequeno y preparar una demo adaptada a su institucion.
