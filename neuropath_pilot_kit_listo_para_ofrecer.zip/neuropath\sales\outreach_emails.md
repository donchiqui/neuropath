# Mensajes de contacto

## Email corto para institucion educativa

Asunto: Piloto de accesibilidad cognitiva para estudiantes

Hola [Nombre],

Estoy preparando NeuroPath, un MVP de accesibilidad cognitiva para equipos educativos. Ayuda a visualizar senales tempranas de fatiga, foco y carga sensorial, y convierte esas senales en recomendaciones simples para estudiantes, docentes e instituciones.

No es una herramienta de diagnostico medico. La propuesta inicial es un piloto con datos ficticios o anonimizados para validar si el enfoque aporta valor a su equipo.

Podemos agendar 30 minutos para mostrar la demo y revisar si encaja con algun programa de apoyo estudiantil?

Gracias,  
[Tu nombre]

## Email para empresa grande o partner

Asunto: NeuroPath - MVP EdTech para accesibilidad cognitiva

Hola [Nombre],

Estoy buscando feedback y posibles aliados para NeuroPath, una plataforma MVP enfocada en accesibilidad cognitiva educativa. El producto combina panel de estudiante, alertas para docentes y metricas institucionales para apoyar decisiones tempranas sin convertir la herramienta en diagnostico medico.

Creemos que puede ser relevante para iniciativas de educacion, inclusion, bienestar, upskilling o alianzas EdTech.

Me gustaria mostrar una demo breve y explorar si existe interes en piloto, partnership o ruta de marketplace.

Saludos,  
[Tu nombre]

## LinkedIn

Hola [Nombre], estoy desarrollando NeuroPath, un MVP de accesibilidad cognitiva para equipos educativos. Ayuda a detectar senales tempranas de fatiga/foco y sugerir acciones simples para estudiantes y docentes. Me gustaria mostrarte una demo breve y recibir feedback desde tu experiencia. Te puedo compartir mas detalles?

## Seguimiento

Hola [Nombre], solo retomo mi mensaje anterior sobre NeuroPath. La propuesta inicial es un piloto pequeno, con datos ficticios o anonimizados, para validar valor antes de cualquier integracion o manejo de datos reales. Si te parece, puedo compartir una demo de 10 minutos esta semana.
