# Pitch Deck - NeuroPath

## 1. Portada

NeuroPath  
Accesibilidad cognitiva para equipos educativos.

## 2. Problema

Los equipos educativos suelen detectar tarde la fatiga cognitiva, la sobrecarga sensorial o la desconexion. Cuando la intervencion llega tarde, el estudiante pierde foco, el docente pierde visibilidad y la institucion pierde capacidad de acompanamiento.

## 3. Usuario objetivo

- Instituciones educativas.
- Programas de bienestar estudiantil.
- Equipos de inclusion y accesibilidad.
- EdTechs que necesitan capa de apoyo cognitivo.
- Empresas con programas de educacion, formacion o upskilling.

## 4. Solucion

NeuroPath combina paneles simples, senales tempranas y recomendaciones de regulacion. Su enfoque es educativo, no clinico.

## 5. Producto actual

MVP funcional con:

- Vista estudiante.
- Vista docente.
- Vista institucional.
- API base.
- Demo navegable.
- Documentacion comercial y tecnica.

## 6. Diferenciador

NeuroPath convierte senales dispersas en acciones breves y utiles. El valor no esta en diagnosticar, sino en ayudar a decidir que hacer ahora.

## 7. Mercado inicial

Entrada recomendada:

- Pilotos pagados con colegios, universidades y programas de apoyo.
- Alianzas con EdTechs.
- Integracion futura con LMS.
- Marketplace cloud cuando el producto este production-ready.

## 8. Modelo de negocio

- Piloto: US$500 a US$1,500.
- Institucion: mensualidad por institucion o por estudiante activo.
- Enterprise: contrato anual con integraciones, soporte y SLA.

## 9. Roadmap

Fase 1: Piloto con datos ficticios o anonimizados.  
Fase 2: Login, base de datos, roles y privacidad avanzada.  
Fase 3: Integraciones LMS y auditoria de accesibilidad.  
Fase 4: Publicacion en AWS Marketplace o Google Cloud Marketplace.

## 10. Uso responsable

No es una herramienta de diagnostico medico. Antes de manejar datos reales de menores, se requieren privacidad, consentimiento, seguridad y contrato institucional.

## 11. Solicitud

Buscamos instituciones o aliados para pilotos iniciales, feedback validado y casos de uso reales.

## 12. Cierre

NeuroPath ayuda a que el acompanamiento llegue antes, sea mas claro y sea menos pesado para estudiantes y docentes.
