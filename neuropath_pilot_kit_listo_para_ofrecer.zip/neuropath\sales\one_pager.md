# NeuroPath - One Pager

## Resumen

NeuroPath es una plataforma MVP de accesibilidad cognitiva para equipos educativos. Ayuda a visualizar senales tempranas de fatiga, sugerir pausas y organizar acompanamiento para estudiantes neurodivergentes.

## Problema

Muchos estudiantes con TDAH, autismo, dislexia u otras necesidades cognitivas reciben apoyo tarde, cuando la fatiga, la frustracion o la desconexion ya son visibles. Los equipos educativos necesitan senales accionables sin convertir el aula en un sistema medico ni sobrecargar al docente.

## Solucion

NeuroPath ofrece tres vistas:

- Estudiante: estado de energia, foco, carga sensorial y recomendacion inmediata.
- Docente: alertas priorizadas y acciones de acompanamiento.
- Institucion: metricas agregadas para programas de apoyo y mejora continua.

## Oferta inicial

Piloto pagado de 14 a 30 dias.

Incluye:

- Demo personalizada.
- Adaptacion del caso de uso con datos ficticios o anonimizados.
- Sesion de presentacion con el equipo.
- Recopilacion de feedback.
- Reporte de recomendaciones para la siguiente fase.

Precio sugerido: US$500 a US$1,500 por piloto inicial.

## Uso responsable

NeuroPath no diagnostica condiciones medicas, no reemplaza profesionales de salud y no debe manejar datos reales de menores sin acuerdos de privacidad, consentimiento y seguridad adecuados.

## Siguiente paso

Agendar una llamada de 30 minutos para revisar el caso de uso y confirmar si el piloto encaja con la institucion.
