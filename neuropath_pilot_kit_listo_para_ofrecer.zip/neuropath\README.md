# NeuroPath

NeuroPath es un MVP EdTech para apoyar accesibilidad cognitiva en estudiantes neurodivergentes. Incluye un panel web, una API inicial y datos de demostracion para presentar el producto a clientes, inversionistas o aliados.

## Estado del producto

Esta version es una base funcional para demo comercial. No debe anunciarse todavia como certificada WCAG, LTI 1.3 o IA clinica hasta completar auditorias e integraciones reales.

## Funciones incluidas

- Panel de estudiante con nivel de energia, foco y senales de fatiga.
- Recomendaciones de regulacion cognitiva.
- Vista docente con alertas de acompanamiento.
- Vista institucional con metricas agregadas.
- API con endpoints de salud, estudiantes, alertas y recomendaciones.
- Frontend estatico listo para demo.
- Docker Compose para correr backend y frontend.
- Documentacion comercial y checklist de venta.

## Ejecutar localmente

### Opcion simple

Abrir `frontend/index.html` en el navegador para ver la demo visual.

### Con API

```bash
cd backend
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Luego abrir `frontend/index.html`.

### Con Docker

```bash
docker compose up --build
```

- Frontend: http://localhost:3000
- Backend: http://localhost:8000
- API docs: http://localhost:8000/docs

## Preparacion para venta

Leer `docs/SALE_READINESS.md` antes de publicar, vender o entregar a terceros.

## Kit comercial

Los materiales para ofrecer el piloto estan en `sales/`:

- `landing.html`: pagina comercial estatica.
- `one_pager.md`: resumen de una pagina para enviar por correo.
- `pitch_deck.md`: guion de presentacion para inversionistas, aliados o empresas.
- `demo_script.md`: guion para presentar la demo en una llamada.
- `outreach_emails.md`: mensajes listos para contactar prospectos.
- `pilot_agreement_template.md`: plantilla base de acuerdo de piloto.
- `privacy_policy_draft.md` y `terms_of_use_draft.md`: borradores no legales definitivos.
- `offer_checklist.md`: pasos para ofrecer NeuroPath hoy.
