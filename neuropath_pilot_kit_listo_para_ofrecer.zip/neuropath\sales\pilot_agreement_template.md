# Plantilla de acuerdo de piloto

Aviso: este documento es una base de trabajo y no reemplaza asesoria legal.

## Partes

Proveedor: [Nombre legal o equipo NeuroPath]  
Cliente piloto: [Nombre de institucion o empresa]

## Objetivo

El objetivo del piloto es evaluar NeuroPath como herramienta educativa de accesibilidad cognitiva para visualizar senales de foco, energia, carga sensorial y recomendaciones de acompanamiento.

## Alcance

El piloto incluye:

- Demo personalizada.
- Configuracion de caso de uso.
- Uso de datos ficticios o anonimizados salvo acuerdo escrito diferente.
- Una sesion de presentacion.
- Una sesion de feedback.
- Reporte final de aprendizajes y recomendaciones.

El piloto no incluye:

- Diagnostico medico.
- Certificacion WCAG o LTI.
- Integraciones con sistemas internos.
- Soporte 24/7.
- Manejo de datos reales de menores sin contrato adicional.

## Duracion

Duracion inicial: [14/30] dias desde la fecha de inicio.

## Precio

Precio del piloto: US$[monto] o equivalente local.  
Forma de pago: [transferencia/factura/link de pago].  
Condiciones: [50% inicio / 50% cierre] o [100% al inicio].

## Datos y privacidad

Por defecto, el piloto se realiza con datos ficticios o anonimizados. Si el cliente solicita usar datos reales, las partes deben firmar un acuerdo adicional de privacidad, seguridad y tratamiento de datos antes de cargar o procesar informacion.

## Propiedad intelectual

NeuroPath y sus componentes pertenecen a [Proveedor]. El cliente recibe acceso limitado para evaluar el piloto durante la duracion acordada.

## Confidencialidad

Las partes se comprometen a no divulgar informacion confidencial recibida durante el piloto sin autorizacion escrita.

## Limitacion de uso

NeuroPath no debe usarse para diagnosticar condiciones medicas ni tomar decisiones disciplinarias o de alto impacto sobre estudiantes sin revision humana profesional.

## Cierre del piloto

Al finalizar, el proveedor entregara un resumen de hallazgos y opciones para continuar:

- Cerrar el piloto.
- Extender el piloto.
- Pasar a implementacion paga.
- Explorar integracion o partnership.

## Firmas

Proveedor: __________________ Fecha: ________

Cliente: ____________________ Fecha: ________
