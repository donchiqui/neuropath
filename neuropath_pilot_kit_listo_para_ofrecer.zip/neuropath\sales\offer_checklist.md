# Checklist para ofrecer NeuroPath hoy

## Antes de enviar

- Reemplazar `[Tu nombre]`, `[Proveedor]`, correos y precios.
- Decidir precio del piloto.
- Elegir duracion: 14 o 30 dias.
- Decidir si se ofrece demo local, demo grabada o demo alojada.
- Confirmar que no se prometen certificaciones todavia.
- Usar datos ficticios o anonimizados.

## Materiales listos

- Landing: `sales/landing.html`
- Demo: `frontend/index.html`
- One pager: `sales/one_pager.md`
- Pitch: `sales/pitch_deck.md`
- Guion de demo: `sales/demo_script.md`
- Emails: `sales/outreach_emails.md`
- Acuerdo piloto: `sales/pilot_agreement_template.md`
- Privacidad: `sales/privacy_policy_draft.md`
- Terminos: `sales/terms_of_use_draft.md`

## Primeros prospectos

- Directores de inclusion educativa.
- Coordinadores de bienestar estudiantil.
- Universidades con programas de apoyo.
- EdTechs pequenas que necesiten accesibilidad.
- Fundaciones de educacion.
- Programas de innovacion de empresas grandes.

## Secuencia recomendada

1. Enviar mensaje corto.
2. Agendar llamada de 30 minutos.
3. Mostrar demo.
4. Preguntar por caso de uso y decisores.
5. Enviar one pager y propuesta piloto.
6. Cerrar alcance, precio y fecha.
7. Usar contrato de piloto antes de trabajar con datos reales.

## Frase de oferta

Estamos ofreciendo un piloto pagado de NeuroPath para validar una capa de accesibilidad cognitiva en entornos educativos. El piloto usa datos ficticios o anonimizados, incluye demo personalizada y entrega un reporte de hallazgos para decidir si tiene sentido avanzar a implementacion.
