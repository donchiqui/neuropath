from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import List

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field


class RiskLevel(str, Enum):
    low = "low"
    medium = "medium"
    high = "high"


class StudentSignal(BaseModel):
    id: str
    name: str
    focus_score: int = Field(ge=0, le=100)
    energy_score: int = Field(ge=0, le=100)
    sensory_load: int = Field(ge=0, le=100)
    risk_level: RiskLevel
    recommended_action: str


class Alert(BaseModel):
    id: str
    student_id: str
    title: str
    message: str
    risk_level: RiskLevel
    created_at: datetime


class InstitutionMetrics(BaseModel):
    active_students: int
    students_needing_support: int
    average_focus_score: int
    regulation_sessions_today: int
    accessibility_status: str


app = FastAPI(
    title="NeuroPath API",
    version="1.0.0-mvp",
    description="API inicial para demo comercial de accesibilidad cognitiva.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


STUDENTS: List[StudentSignal] = [
    StudentSignal(
        id="stu-001",
        name="Ana Rivera",
        focus_score=82,
        energy_score=74,
        sensory_load=32,
        risk_level=RiskLevel.low,
        recommended_action="Mantener bloque de enfoque por 20 minutos.",
    ),
    StudentSignal(
        id="stu-002",
        name="Mateo Solis",
        focus_score=46,
        energy_score=39,
        sensory_load=78,
        risk_level=RiskLevel.high,
        recommended_action="Activar pausa sensorial y reducir carga visual.",
    ),
    StudentSignal(
        id="stu-003",
        name="Lucia Moreno",
        focus_score=63,
        energy_score=58,
        sensory_load=55,
        risk_level=RiskLevel.medium,
        recommended_action="Dividir tarea en pasos cortos con temporizador.",
    ),
]


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "neuropath-api"}


@app.get("/api/v1/students", response_model=List[StudentSignal])
def list_students() -> List[StudentSignal]:
    return STUDENTS


@app.get("/api/v1/alerts", response_model=List[Alert])
def list_alerts() -> List[Alert]:
    now = datetime.now(timezone.utc)
    return [
        Alert(
            id="alt-001",
            student_id="stu-002",
            title="Carga sensorial elevada",
            message="Mateo muestra senales de fatiga. Se recomienda pausa guiada.",
            risk_level=RiskLevel.high,
            created_at=now,
        ),
        Alert(
            id="alt-002",
            student_id="stu-003",
            title="Atencion fluctuante",
            message="Lucia podria beneficiarse de una tarea dividida en pasos.",
            risk_level=RiskLevel.medium,
            created_at=now,
        ),
    ]


@app.get("/api/v1/recommendations")
def recommendations() -> dict[str, list[str]]:
    return {
        "student": [
            "Respirar 60 segundos antes de continuar.",
            "Usar modo foco con una sola tarea visible.",
            "Elegir una pausa corta si la carga sensorial sube.",
        ],
        "teacher": [
            "Priorizar instrucciones breves y verificables.",
            "Ofrecer alternativa escrita cuando haya fatiga.",
            "Revisar alertas de alto riesgo antes de cerrar la clase.",
        ],
        "institution": [
            "Monitorear tendencias por cohorte, no diagnosticos individuales.",
            "Documentar intervenciones y consentimiento de datos.",
            "Separar metricas educativas de informacion medica.",
        ],
    }


@app.get("/api/v1/metrics", response_model=InstitutionMetrics)
def metrics() -> InstitutionMetrics:
    needing_support = len([student for student in STUDENTS if student.risk_level != RiskLevel.low])
    average_focus = round(sum(student.focus_score for student in STUDENTS) / len(STUDENTS))
    return InstitutionMetrics(
        active_students=len(STUDENTS),
        students_needing_support=needing_support,
        average_focus_score=average_focus,
        regulation_sessions_today=18,
        accessibility_status="MVP preparado para auditoria",
    )
