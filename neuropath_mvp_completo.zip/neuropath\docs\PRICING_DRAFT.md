# Borrador de precios

Estos precios son una base para conversacion, no una oferta legal definitiva.

## Plan Demo

- Uso: pilotos con instituciones pequenas.
- Precio sugerido: gratis por 14 dias.
- Incluye: panel demo, datos de ejemplo, presentacion guiada.

## Plan Institucion

- Uso: colegios, universidades o programas de apoyo.
- Precio sugerido: pago mensual por institucion o por estudiante activo.
- Incluye: paneles, soporte, reportes y configuracion inicial.

## Plan Enterprise

- Uso: redes educativas o integraciones LMS.
- Precio sugerido: contrato anual.
- Incluye: integraciones, seguridad avanzada, SSO, soporte prioritario y SLA.
