# Notas legales iniciales

Este documento no reemplaza asesoria legal.

## Privacidad

NeuroPath puede manejar informacion sensible de estudiantes. Antes de vender, definir:

- Que datos se recopilan.
- Para que se usan.
- Quien puede verlos.
- Como se eliminan.
- Como se obtiene consentimiento.

## Salud y educacion

El producto debe presentarse como apoyo educativo, no como diagnostico medico. Las referencias a TDAH, autismo o dislexia deben tratarse con cuidado y respeto.

## Licencia

Si el proyecto original esta bajo MIT, se puede vender software basado en el, pero tambien otras personas podrian reutilizarlo si tienen acceso al codigo. Para una venta cerrada o SaaS propietario, revisar estrategia de licencia y repositorio privado.
