# Checklist para venta

## Listo en esta version

- Demo visual navegable.
- API basica documentada por FastAPI.
- Docker Compose para demostracion.
- Mensaje comercial responsable.
- Separacion entre demo, producto y futuras certificaciones.

## Antes de vender como SaaS

- Definir dueno legal del producto y permisos de cada colaborador.
- Crear terminos de uso, politica de privacidad y politica de datos educativos.
- Agregar autenticacion real.
- Agregar pagos, facturacion o licenciamiento.
- Configurar dominio, HTTPS, monitoreo y backups.
- Reemplazar datos demo por base de datos real.
- Auditar accesibilidad antes de anunciar WCAG 2.1 AA.
- Implementar y certificar integraciones LTI 1.3 antes de anunciarlas como disponibles.
- Revisar todo reclamo de IA para que sea demostrable y no medico/clinico.

## Posicionamiento recomendado

Usar esta frase en ventas iniciales:

> NeuroPath es una plataforma en MVP para acompanamiento educativo y accesibilidad cognitiva, enfocada en senales tempranas, pausas guiadas y paneles de seguimiento para equipos academicos.

Evitar por ahora:

- "Certificado WCAG 2.1 AA".
- "LTI 1.3 certificado".
- "Diagnostica TDAH, autismo o dislexia".
- "IA predictiva clinicamente validada".
