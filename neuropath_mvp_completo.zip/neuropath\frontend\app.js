const apiBase = window.NEUROPATH_API_URL || "http://localhost:8000";

const fallbackStudents = [
  {
    id: "stu-001",
    name: "Ana Rivera",
    focus_score: 82,
    energy_score: 74,
    sensory_load: 32,
    risk_level: "low",
    recommended_action: "Mantener bloque de enfoque por 20 minutos."
  },
  {
    id: "stu-002",
    name: "Mateo Solis",
    focus_score: 46,
    energy_score: 39,
    sensory_load: 78,
    risk_level: "high",
    recommended_action: "Activar pausa sensorial y reducir carga visual."
  },
  {
    id: "stu-003",
    name: "Lucia Moreno",
    focus_score: 63,
    energy_score: 58,
    sensory_load: 55,
    risk_level: "medium",
    recommended_action: "Dividir tarea en pasos cortos con temporizador."
  }
];

const fallbackAlerts = [
  {
    title: "Carga sensorial elevada",
    message: "Mateo muestra senales de fatiga. Se recomienda pausa guiada.",
    risk_level: "high"
  },
  {
    title: "Atencion fluctuante",
    message: "Lucia podria beneficiarse de una tarea dividida en pasos.",
    risk_level: "medium"
  }
];

const fallbackMetrics = {
  active_students: 3,
  students_needing_support: 2,
  average_focus_score: 64,
  regulation_sessions_today: 18
};

const riskLabel = {
  low: "estable",
  medium: "atencion",
  high: "prioridad"
};

document.querySelectorAll(".tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((item) => item.classList.remove("active"));
    document.querySelectorAll(".view").forEach((view) => view.classList.remove("active-view"));
    tab.classList.add("active");
    document.getElementById(tab.dataset.view).classList.add("active-view");
  });
});

async function getJson(path, fallback) {
  try {
    const response = await fetch(`${apiBase}${path}`);
    if (!response.ok) throw new Error("API unavailable");
    document.getElementById("api-status").textContent = "Conectada";
    return await response.json();
  } catch {
    document.getElementById("api-status").textContent = "Demo sin API";
    return fallback;
  }
}

function scoreBlock(label, value) {
  return `
    <div>
      <p>${label}: <strong>${value}</strong></p>
      <div class="bar" aria-hidden="true"><span style="width:${value}%"></span></div>
    </div>
  `;
}

function renderStudents(students) {
  const container = document.getElementById("student-cards");
  container.innerHTML = students
    .map(
      (student) => `
        <article class="card">
          <header>
            <h3>${student.name}</h3>
            <span class="pill ${student.risk_level}">${riskLabel[student.risk_level]}</span>
          </header>
          ${scoreBlock("Foco", student.focus_score)}
          ${scoreBlock("Energia", student.energy_score)}
          ${scoreBlock("Carga sensorial", student.sensory_load)}
          <p>${student.recommended_action}</p>
        </article>
      `
    )
    .join("");
}

function renderAlerts(alerts) {
  const container = document.getElementById("alerts");
  container.innerHTML = alerts
    .map(
      (alert) => `
        <article class="card">
          <header>
            <h3>${alert.title}</h3>
            <span class="pill ${alert.risk_level}">${riskLabel[alert.risk_level]}</span>
          </header>
          <p>${alert.message}</p>
        </article>
      `
    )
    .join("");
}

function renderMetrics(metrics) {
  const items = [
    ["Estudiantes activos", metrics.active_students],
    ["Necesitan apoyo", metrics.students_needing_support],
    ["Foco promedio", `${metrics.average_focus_score}%`],
    ["Pausas hoy", metrics.regulation_sessions_today]
  ];

  document.getElementById("metrics").innerHTML = items
    .map(([label, value]) => `<div class="metric"><strong>${value}</strong><span>${label}</span></div>`)
    .join("");
}

let remaining = 20 * 60;
let intervalId;

document.getElementById("start-focus").addEventListener("click", () => {
  clearInterval(intervalId);
  remaining = 20 * 60;
  intervalId = setInterval(() => {
    remaining = Math.max(0, remaining - 1);
    const minutes = String(Math.floor(remaining / 60)).padStart(2, "0");
    const seconds = String(remaining % 60).padStart(2, "0");
    document.getElementById("timer").textContent = `${minutes}:${seconds}`;
    if (remaining === 0) clearInterval(intervalId);
  }, 1000);
});

async function start() {
  renderStudents(await getJson("/api/v1/students", fallbackStudents));
  renderAlerts(await getJson("/api/v1/alerts", fallbackAlerts));
  renderMetrics(await getJson("/api/v1/metrics", fallbackMetrics));
}

start();
